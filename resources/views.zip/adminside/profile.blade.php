@extends('layouts.admin.app')
@section('content')

@stop